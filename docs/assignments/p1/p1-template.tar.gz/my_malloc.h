#ifndef __MY_MALLOC_H
#define __MY_MALLOC_H

#include <stdlib.h>

void my_malloc_init(size_t default_size, size_t num_arenas);

void my_malloc_destroy(void);

void* my_malloc(size_t size);

#endif /* __MY_MALLOC_H */
