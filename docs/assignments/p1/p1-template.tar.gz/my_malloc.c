#include "my_malloc.h"

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>

void my_malloc_init(size_t default_size, size_t num_arenas) { 
  // Fill in
}

void my_malloc_destroy(void) { 
  // Fill in
}

void* my_malloc(size_t size) {
	return NULL;
}

