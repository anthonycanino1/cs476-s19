#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
#include <time.h>

#include "warmup.h"

#define MB_1 (1024 * 1024)

ivec* gen_ivec(int nentries) {
  ivec *iv = new_ivec(nentries);
  for (int i = 0; i < nentries; i++) {
    insert(iv, rand() % 100);
  }
  return iv;
}

ivec* dup_ivec(ivec *iv) {
  ivec *iv2 = new_ivec(iv->cap);
  memcpy(iv2->arr, iv->arr, sizeof(int) * iv->size);
  iv2->size = iv->size;
  return iv2;
}

// Global state
ivec *iv1, *iv2;
int niters = 0;
int nthreads = 0;

void serial_process() {

} 

void* do_parallel_process(void *ptr) {
}

void parallel_process() {
}

int main(int argc, char **argv) {
  if (argc < 4) {
    fprintf(stderr, "%s usage: [ENTRIES] [NUMBER THREADS] [NUMBER LOOPS]\n", argv[0]);
    return 1;
  }

  size_t nentries = strtoll(argv[1], NULL, 10);
  nthreads = strtol(argv[2], NULL, 10);
  niters = strtoll(argv[3], NULL, 10);
  
  srand(time(NULL));

  iv1 = gen_ivec(nentries);
  iv2 = dup_ivec(iv1);

  fprintf(stdout, "Vector loaded!\n");

  if (nthreads <= 1) {
    serial_process();
  } else {
    parallel_process();
  }

  fprintf(stdout, "Vector processed!\n");

  for (int i = 0; i < iv1->size; i++) {
    assert(iv1->arr[i] * (niters+1) == iv2->arr[i]);
  }

  fprintf(stdout, "All good!\n");

  free_ivec(iv1);
  free_ivec(iv2);

  return 0;
}


