/*********************************************************************
* Warmup Exercise for Lecture 2: Multicore Programming in C
*
* Fill in functions *new_ivec*, *free_ivec*, and *insert* below
*
* Compile with 'gcc --std=c11 warmup.c -o warmup'. Run with `./warmup
*
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "warmup.h"

ivec* new_ivec(int cap) {
  // Fill in
}

void free_ivec(ivec *iv) {
  // Fill in
}

void insert(ivec *iv, int val) {
  // Fill in here
  // Make use of memcpy function to copy from one array into another
  // memcpy(dest, src, size)
}

int main(int argc, char **argv) {
  // Create an initial int vector with capacity of 8
  ivec *iv = new_ivec(8);

  // Insert 20 values into int vector. This will force two array resizings.
  for (int i = 0; i < 20; i++) {
    insert(iv, i);
  }

  // A simple assert will check for correctness. VERY crude form
  // of testing in C.
  assert(iv->size == 20); 
  assert(iv->cap == 32); 
  assert(iv->arr[10] == 10);

  printf("Correct!\n");

  // Clean up allocation
  free_ivec(iv);

  return 0;
}
