typedef struct {
  int *arr;
  int size;
  int cap;
} ivec;

ivec* new_ivec(int cap);
void free_ivec(ivec *iv);
void insert(ivec *iv, int val);

